# CLAUDE.md

Operational guide for Claude Code working in P2-Knowledge-Base repository.

## 🚨 SESSION START PROTOCOL - DO THIS FIRST!

### 1. Model Check & Work Assessment
```
I'm running on [Opus 4.1 / Sonnet 3.5 / Haiku 3.5]

Looking at today's work:
- [ Planning/Strategy/Ambiguous ] → Should be in Opus (currently am/switch needed)
- [ Execution/Following templates ] → Should be in Sonnet (save 66% cost)
- [ Simple queries/Validation ] → Could use Haiku (save 90% cost)

Are we in the right model for today's work?
```

### 2. Remember the Key Documents:

#### 🔴 CRITICAL - Update These When Structure Changes:
- **`README.md`** - Public documentation (what users see)
- **`.claude/project-structure.md`** - Internal structure (versioned vs non-versioned dirs)

**REMINDER**: When directories change, hidden files move, or .gitignore updates,
BOTH files above need updating! Check them at session start!

#### Also Important:
- **`PROJECT-MASTER.md`** - Single source of truth (project goals, sprints)
- **`CLAUDE.md`** - This AI operational guide (in .gitignore)

### 3. Restore Context:
```bash
mcp__todo-mcp__context_resume    # Shows current state + tasks
```
This recovers context, shows active tasks, and restores working memory.

### 4. Check Model Phase Hint:
Look for `model_phase` context key suggesting which model phase we're in:
- 'planning' → Opus recommended
- 'execution' → Sonnet recommended  
- 'validation' → Haiku possible

## 🎯 Critical Operations

### Recovery After Interruption
```bash
mcp__todo-mcp__context_resume    # Shows current state + tasks
```

### 🛡️ Defensive Work Process (CRITICAL - Prevents Duplicate Work)
**ALWAYS follow this before starting any task:**

1. **Pre-Work Validation Checklist:**
   ```bash
   # Check if deliverable already exists
   mcp__filesystem__read_text_file path:"/path/to/expected/deliverable"
   
   # If deliverable exists and is complete:
   mcp__todo-mcp__todo_delete id:[task_id]  # Delete duplicate task
   
   # If deliverable is partial/needs work:
   # Proceed with task but note existing content
   ```

2. **Ultra-Safe Bulk Operations:**
   ```bash
   # BEFORE any dangerous bulk operation:
   mcp__todo-mcp__project_dump include_context:true
   
   # Note the backup filename, then proceed
   # If operation fails:
   mcp__todo-mcp__project_restore file:"backup_filename.json" mode:"replace" include_context:true
   ```

3. **Task-Work Sync Rules:**
   - START task before beginning work: `mcp__todo-mcp__todo_start id:[task_id]`
   - COMPLETE task immediately after finishing: `mcp__todo-mcp__todo_complete position_id:[position]`
   - REFRESH list after completing to get new positions
   - If deliverable already exists: DELETE task instead of duplicating work

**Why This Matters:** Prevents doing work 2-3 times, maintains accurate time tracking, avoids data loss during bulk operations.

### 🗃️ Defensive Archiving Process (Prevents Duplicate Archives)
**ALWAYS check before archiving:**

1. **Check Existing Archives:**
   ```bash
   # Check if task already archived
   mcp__filesystem__search_files path:"/tasks/archives/" pattern:"*archive*"
   # Look for task ID in existing archives before creating new one
   ```

2. **Archive Processing Rules:**
   - Process archives in date order: oldest first → newest
   - **First One Wins Principle**: If task appears in multiple archives, use first occurrence
   - Don't archive completed tasks that are already in archives
   - Use defensive checking before mcp__todo-mcp__todo_archive

3. **Archive Summary Strategy:**
   - Task #527: "Archive Todo-MCP tasks and generate time metrics"
   - Process ALL archive files chronologically
   - Apply first-one-wins for duplicate task completion data
   - Generate combined metrics from all archives
   - Handle v0.6.8 persistence issues by using archive data as source of truth

**Why Critical:** v0.6.8 persistence issues mean archives are more reliable than live task state for historical metrics.

### Task Management 
**Todo-MCP v0.6.8 Parameter Rules:**
- Most functions: `id:22` (number, no #)
- Only 3 dual-parameter: complete, tag_add, tag_remove accept `position_id:1` OR `task_id:"#22"`
- **CRITICAL**: Task IDs in angle brackets like «#492» must include the # when passed to todo-mcp (e.g., `task_id:"#492"`)
- Always: `estimate_minutes:60` (number not string)
- Details: `.claude/claude-reference/TODO-MCP-PARAMETER-TRUTH.md`

### Late Discovery Task Reordering (When Sprint Planning Missed Dependencies)
**Pattern for Recovery When Task Order is Wrong:**

1. **Extract to TodoWrite**: Pull full task list with phase labels for human review
2. **Bulk Priority Updates**: Use `todo_bulk set_priority` to group logical phases
   - Critical → High → Medium → Low → Backlog
3. **Position ID vs Task ID Rule**: 
   - Position IDs are relative to current list view (must show list first!)
   - Task IDs are absolute (#503, #504) - use for specific updates
4. **Sequence Within Priority**: Use sequence numbers for dependencies within same priority

**Success Pattern**: TodoWrite → Bulk Priority → Task ID updates → Document lessons
**Failure Analysis**: Always indicates sprint planning didn't analyze dependencies properly
**Root Cause**: Need dependency analysis during initial planning phase

**Note**: v0.6.8.1 coming soon to fix interface issues

### 🎯 CRITICAL Task Sync Rules
**ALWAYS maintain sync between work and task tracking:**
1. **START before work**: `mcp__todo-mcp__todo_start` with `id:position` (NOT task ID!)
2. **COMPLETE after work**: `mcp__todo-mcp__todo_complete` with `position_id:position`
3. **REFRESH after complete**: Positions change! Get fresh list before next operation
4. **ARCHIVE when done**: `mcp__todo-mcp__todo_archive` to clean completed tasks
5. **POSITION != ID**: Position is line number in current list view, NOT the «#XXX» ID

**Common Sync Issues:**
- Doing work without starting task = no time metrics
- Not completing tasks = cluttered list, wrong status
- Using task ID instead of position = errors
- Not refreshing list = wrong positions after complete

**Recovery from Sync Issues:**
- Check file creation times for actual work timing
- Use `mcp__todo-mcp__todo_bulk` to fix multiple statuses
- Archive completed tasks to clean up

### 🚨 CRITICAL: File System Access Rules
**FILESYSTEM MCP IS YOUR PRIMARY TOOL - ALWAYS USE IT FIRST**

#### GO-TO Tools (Use These FIRST):
- `mcp__filesystem__read_text_file` - NOT cat, NOT Bash read
- `mcp__filesystem__read_multiple_files` - Batch reading files
- `mcp__filesystem__write_file` - NOT echo, NOT Bash write
- `mcp__filesystem__edit_file` - For precise edits
- `mcp__filesystem__search_files` - NOT find, NOT grep for filenames
- `mcp__filesystem__list_directory` - NOT ls, NOT Bash listing
- `mcp__filesystem__create_directory` - NOT mkdir
- `mcp__filesystem__get_file_info` - NOT stat

#### ONLY Use Bash For:
- Git operations (git add, commit, diff, status)
- External programs (npm, python, compilers)
- Text processing on content (sed, awk - but prefer MCP edit)
- Running/testing code

#### Why Filesystem MCP First:
- Faster response times (no shell overhead)
- More reliable (built-in error handling)
- Better for context (structured responses)
- Reduces API latency impact

**REMEMBER: If you're about to use Bash for file operations, STOP and use filesystem MCP instead!**

## 📁 Project Context

**Repository**: P2 (Propeller 2) microcontroller documentation system
**Purpose**: AI-optimized technical documentation for code generation
**Status**: V2 extraction complete - 80% coverage achieved (was 55% in V1)

### Hidden/Non-Versioned Directories (in .gitignore)
- `/import/` - Source .docx/.xlsx files from Google Docs (not committed)
- `/.claude/` - AI reference materials and guides (not committed)
- `/sources/extractions-v1-archived/` - Obsolete V1 extractions (not committed)
- `.DS_Store` files - macOS metadata (auto-ignored)

### Key Technical Context
- **Architecture**: 8-cog multiprocessor, 64 Smart Pins, CORDIC solver
- **Languages**: PASM2 (assembly), Spin2 (high-level with inline assembly)
- **Focus**: Enabling AI to generate production-quality P2 code

## 📋 Todo-MCP Operational Patterns

### Successful Task Reordering Techniques (2025-08-15)

**When to Reorder**: Late discovery that task dependencies weren't properly analyzed

**Method 1: TodoWrite Visualization + Bulk Priority**
```
1. Extract all sprint tasks to TodoWrite with phase labels
2. Human reviews logical flow and dependencies  
3. Use mcp__todo-mcp__todo_bulk set_priority to group phases
4. Result: Priority-based automatic reordering
```

**Method 2: Individual Task Updates** (when bulk isn't enough)
```
1. Show current list to get position universe
2. Use task IDs for specific updates when possible
3. Set sequence numbers within same priority level
```

**Critical Rules Learned**:
- Position IDs change every time you show the list (relative universe)
- Task IDs are permanent (#503, #504) - prefer when possible
- Bulk operations are more reliable than individual updates
- Always document reordering reasons for future sprint planning

**V0.6.8 Interface Issues**: Extract/audit sequence display still problematic, v0.6.8.1 will fix

## 🔧 Development Patterns

### Sprint Methodology
- Question exhaustion planning (done when no questions remain)
- Capability-driven development (what knowledge we're adding)
- Sprint documentation in `.sprints/[sprint-name]/`
- Git releases for knowledge milestones

### Documentation Standards
- Verify against official P2 sources
- Track source lineage (page/row numbers)
- Minimal document count, maximum effectiveness
- Cross-reference between related topics

## 📚 External References

**Comprehensive Guides** in `.claude/`:
- `claude-process/CRASH-RECOVERY-PROCEDURE.md` - Full recovery workflow
- `claude-reference/TODO-MCP-V068-CONSOLIDATED-BEST-PRACTICES.md` - Complete MCP guide
- `claude-process/dual-system-strategy.md` - TodoWrite + MCP coordination

**Project Documentation**:
- `PROJECT-MASTER.md` - Single source of truth
- `.sprints/*/sprint-summary.md` - Sprint outcomes
- `tools/sprint-lifecycle-methodology.md` - Complete sprint process